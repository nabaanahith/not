package com.example.nabaa96.myapplicationnm.callbacks;

import com.example.nabaa96.myapplicationnm.Comment;

public interface OnLikeCommentListener {

    void onLikeComment(Comment comment,int position);
}
