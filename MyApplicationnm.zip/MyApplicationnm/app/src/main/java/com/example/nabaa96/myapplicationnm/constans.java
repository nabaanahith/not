package com.example.nabaa96.myapplicationnm;

public class constans {

    public  static final  String channelid="mychannelid";
    public  static final  String channelname="mychannelname";
    public  static final  String channedescription="mychanneldescription";
}
